import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-policy-payment',
  templateUrl: './view-policy-payment.component.html',
  styleUrls: ['./view-policy-payment.component.css']
})
export class ViewPolicyPaymentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
