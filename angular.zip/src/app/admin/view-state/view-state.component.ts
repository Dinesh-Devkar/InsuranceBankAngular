import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-state',
  templateUrl: './view-state.component.html',
  styleUrls: ['./view-state.component.css']
})
export class ViewStateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
