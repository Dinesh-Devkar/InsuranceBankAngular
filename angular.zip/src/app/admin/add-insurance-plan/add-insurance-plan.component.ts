import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-insurance-plan',
  templateUrl: './add-insurance-plan.component.html',
  styleUrls: ['./add-insurance-plan.component.css']
})
export class AddInsurancePlanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
