import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-commision-withdrwal',
  templateUrl: './commision-withdrwal.component.html',
  styleUrls: ['./commision-withdrwal.component.css']
})
export class CommisionWithdrwalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
