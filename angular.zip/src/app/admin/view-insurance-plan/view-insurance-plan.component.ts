import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-insurance-plan',
  templateUrl: './view-insurance-plan.component.html',
  styleUrls: ['./view-insurance-plan.component.css']
})
export class ViewInsurancePlanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
