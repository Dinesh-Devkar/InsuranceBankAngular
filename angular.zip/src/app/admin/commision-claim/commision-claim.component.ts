import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-commision-claim',
  templateUrl: './commision-claim.component.html',
  styleUrls: ['./commision-claim.component.css']
})
export class CommisionClaimComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
