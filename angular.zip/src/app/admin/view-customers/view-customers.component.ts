import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-customers',
  templateUrl: './view-customers.component.html',
  styleUrls: ['./view-customers.component.css']
})
export class ViewCustomersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
