import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-insurance-setting',
  templateUrl: './insurance-setting.component.html',
  styleUrls: ['./insurance-setting.component.css']
})
export class InsuranceSettingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
