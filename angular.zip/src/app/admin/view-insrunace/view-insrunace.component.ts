import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-insrunace',
  templateUrl: './view-insrunace.component.html',
  styleUrls: ['./view-insrunace.component.css']
})
export class ViewInsrunaceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
