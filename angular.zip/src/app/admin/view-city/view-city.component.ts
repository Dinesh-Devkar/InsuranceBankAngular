import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-city',
  templateUrl: './view-city.component.html',
  styleUrls: ['./view-city.component.css']
})
export class ViewCityComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
