import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-commision',
  templateUrl: './view-commision.component.html',
  styleUrls: ['./view-commision.component.css']
})
export class ViewCommisionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
