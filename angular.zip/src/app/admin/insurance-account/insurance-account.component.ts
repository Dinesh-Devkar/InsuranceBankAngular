import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-insurance-account',
  templateUrl: './insurance-account.component.html',
  styleUrls: ['./insurance-account.component.css']
})
export class InsuranceAccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
