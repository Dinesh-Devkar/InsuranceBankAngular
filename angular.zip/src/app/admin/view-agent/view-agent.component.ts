import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-agent',
  templateUrl: './view-agent.component.html',
  styleUrls: ['./view-agent.component.css']
})
export class ViewAgentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
