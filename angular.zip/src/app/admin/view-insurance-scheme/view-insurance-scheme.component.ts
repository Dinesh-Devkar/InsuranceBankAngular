import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-insurance-scheme',
  templateUrl: './view-insurance-scheme.component.html',
  styleUrls: ['./view-insurance-scheme.component.css']
})
export class ViewInsuranceSchemeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
