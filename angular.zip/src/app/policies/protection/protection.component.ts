import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-protection',
  templateUrl: './protection.component.html',
  styleUrls: ['./protection.component.css']
})
export class ProtectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
