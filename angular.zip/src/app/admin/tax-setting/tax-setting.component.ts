import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tax-setting',
  templateUrl: './tax-setting.component.html',
  styleUrls: ['./tax-setting.component.css']
})
export class TaxSettingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
